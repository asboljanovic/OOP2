package pitanja;

import pitanja.ZbirkaPitanja.Elem;

public class IteratorPitanja {
	
	private  ZbirkaPitanja zp;
	private Elem tek;
	public IteratorPitanja(ZbirkaPitanja p) {
		zp = p;	
		tek = zp.prvi;
	}
	
	

	
	
	public boolean postoji(){ 
		if (tek == null)return false;
		else return true;	   	
		
	}
	public Pitanje dohvati() throws GNemaPitanja {
		if (tek == null) throw new GNemaPitanja();
		return tek.p; }
	
	public void sledece() throws GNemaPitanja { 
		if( tek.sled == null) throw new GNemaPitanja();
		tek = tek.sled;
	}
	

}
