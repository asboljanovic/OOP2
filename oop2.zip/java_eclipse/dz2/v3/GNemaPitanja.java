package pitanja;

public class GNemaPitanja extends Exception {
	
	public String toString() {
		return "*** GRESKA!!! NEMA PITANJA!!! ***";
	}

}
