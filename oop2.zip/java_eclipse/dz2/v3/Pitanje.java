package pitanja;

public class Pitanje implements Cloneable {
	private static int posId = 0;
	private int id;
	
	private String tekst;
	private int brPoena;
	private double tezina;
	
	public Pitanje(String te, int br, double t) {
		tekst = te; brPoena = br; tezina = t;
		id = ++posId;
	}
	
	public String dohvTekst() { return tekst; }
	
	public int dohvBrPoena() { return brPoena; }
	public double dohvTezinu() { return tezina; }
	
	public String toString() {
		return "Pitanje " + id + ":" + tekst;
	}
	
	public Pitanje clone() {
		Pitanje kopija = null;
		try {
			kopija = (Pitanje)super.clone();
			kopija.id = id;
			
		} catch (CloneNotSupportedException e ) { e.printStackTrace(); }
		
		return kopija;
	}
	  
	public Pitanje kopija() { return clone(); }
	

}
