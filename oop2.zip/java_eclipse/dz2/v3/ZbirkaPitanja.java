package pitanja;

public class ZbirkaPitanja {
	
	public static class Elem {
		Pitanje p;
		Elem sled;
		Elem(Pitanje pp) { p = pp; }
	}
	public Elem prvi, posl;
	
	public ZbirkaPitanja() {}
	
	public ZbirkaPitanja dodaj(Pitanje p) {
		Elem novi = new Elem(p);
		if (prvi == null) { prvi = novi;}
		else posl.sled = novi;
		posl = novi;
		return this;
	}
	
	public Pitanje dohvati (int i) throws GNemaPitanja {
		if ( i < 0 ) throw new GNemaPitanja();
		int b = 0;
		for(Elem tek = prvi ; tek!= null; tek = tek.sled  ) {
			if ( b ==i ) return tek.p; 
			b++;
		}
		if(i>=b) throw new GNemaPitanja();
		return null;
		
	}
	public int broj() {
        int b = 0;
		for(Elem tek = prvi ; tek!= null; tek = tek.sled  ) b++;
		return b;
		
	}
	

	
	public IteratorPitanja iterator() {
		
	
	IteratorPitanja ip = new IteratorPitanja(this);
	
	return ip;
	} 
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(Elem tek = prvi ; tek!= null; tek = tek.sled  ) {
			
			sb.append(tek.p + "\n");
			sb.append("\n");
			
			
		}
		return sb.toString();
	}

}
