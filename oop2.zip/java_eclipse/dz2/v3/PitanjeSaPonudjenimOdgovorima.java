package pitanja;

public class PitanjeSaPonudjenimOdgovorima extends Pitanje {
	
	private String [] nizPonudjenih;
	
	public PitanjeSaPonudjenimOdgovorima(String te, int br, double t, String[] n) {
		super(te,br,t);
		nizPonudjenih = n;
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder(super.toString() + "\n");
		int b = 1;
		for (int i = 0; i< nizPonudjenih.length; i++) {
			sb.append("\t" + b+ ". " + nizPonudjenih[i] +"\n"); b++;
		}
		return sb.toString();
	}

}
