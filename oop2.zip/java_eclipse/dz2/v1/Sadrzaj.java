package raspored;

public abstract class Sadrzaj {
	
	private String naziv;
	private Vreme trajanje, pocetno;
	
	public Sadrzaj (String n , Vreme t) {
		naziv = n; trajanje  = t;
		pocetno = new Vreme();
	}
	
	public String dohvNaziv() { return naziv; }
	public Vreme dohvTrajanje() { return trajanje; }
	public Vreme dohvPocetak() { return pocetno; }
	
	public void postaviPocetno(Vreme v) {
		pocetno = v;
	}
		
	
	public abstract Vreme preklapaSe(Sadrzaj s) throws GVreme;

	
	public abstract void pomeri(Vreme v) throws GVreme;
	
	public  Vreme krajnjeVremeSadrzaja() throws GVreme {
		Vreme t = pocetno.saberi(pocetno, trajanje); return t;
	}
	
	public abstract char vrsta();
	public String toString() {
		try {
			return vrsta() + "," + naziv + "|" + pocetno + krajnjeVremeSadrzaja();
		} catch (GVreme e) {
			
			e.printStackTrace();
		} return "";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
