package raspored;

public class Ponavljajuci extends Sadrzaj  {
	
	private Vreme period;
	
	
	public Ponavljajuci(String n, Vreme t, Vreme p) throws GVreme {
		super(n,t);
		period = p;
		
	}
	

		
	
	public void pomeri(Vreme v) throws GVreme {
		
		if (v.minuti() == 0) {
			return;
		}
		
		Vreme pomerenPocetak = this.dohvPocetak().saberi(this.dohvPocetak(), v);
		Vreme kraj = this.dohvPocetak().saberi(this.dohvPocetak(), this.dohvTrajanje());
		Vreme pomerenKraj = kraj.saberi(kraj, v);
				
		
		if (pomerenPocetak.minuti() > 1425 || pomerenKraj.minuti() > 1425) {
			return;
		}
		
		this.postaviPocetno(pomerenPocetak);
		
		
		
//		this.postaviPocetno(this.dohv);
	}
    
	
	public Vreme dohvPeriod() {
		return period;
	}
	
	public char vrsta() {
	
		return 'P';
	}
	
	


	
	public String toString() {
		return super.toString() + "T" + period;
	}



	




	
	public Vreme preklapaSe(Sadrzaj s) throws GVreme {
		
		if (this.dohvPocetak().jednako(s.dohvPocetak())) {
			return s.dohvPocetak();
		}
		
		//kroz neki while pomerati pocetak i radis sve isto dole

		int minutiPrvogPocetak = this.dohvPocetak().minuti();
//		int minutiDrugogPocetak = s.dohvPocetak().dohvVreme();
		
		Vreme tmpVreme = new Vreme();
		Vreme prviVremeKraj = tmpVreme.saberi(this.dohvPocetak(), this.dohvTrajanje());
//		Vreme drugoVremeKraj = tmpVreme.saberi(s.dohvPocetak(), s.dohvTrajanje());

		int minutiPrvogKraj = prviVremeKraj.minuti();
//		int minutiDrugogKraj = drugoVremeKraj.dohvVreme();

		
		
			while (minutiPrvogKraj < 1425) {
				//ovde cemo menjati prvi ili na kraju
				//npr prvi = 150min
				int minutiDrugogPocetak = s.dohvPocetak().minuti();
				Vreme drugoVremeKraj = tmpVreme.saberi(s.dohvPocetak(), s.dohvTrajanje());
				int minutiDrugogKraj = drugoVremeKraj.minuti();
				if((s instanceof Ponavljajuci)) {
					while (minutiDrugogKraj < 1425) { 
						
						if(minutiPrvogPocetak > minutiDrugogPocetak) {
							if (minutiDrugogKraj > minutiPrvogPocetak) {
								return new Vreme((minutiPrvogPocetak/60)%24, minutiPrvogPocetak%60);
							}
						}else if(minutiPrvogPocetak < minutiDrugogPocetak) {
							if(minutiPrvogKraj > minutiDrugogPocetak) {
								return new Vreme((minutiDrugogPocetak/60)%24, minutiDrugogPocetak%60);
								
							}
						}else {
							return new Vreme((minutiDrugogPocetak/60)%24, minutiDrugogPocetak%60);
						}
						
						minutiDrugogKraj += ((Ponavljajuci) s).dohvPeriod().minuti();
						minutiDrugogPocetak += ((Ponavljajuci) s).dohvPeriod().minuti();
					}
				}else {
					if(minutiPrvogPocetak > minutiDrugogPocetak) {
						if (minutiDrugogKraj > minutiPrvogPocetak) {
							return new Vreme((minutiPrvogPocetak/60)%24, minutiPrvogPocetak%60);
						}
					}else if(minutiPrvogPocetak < minutiDrugogPocetak) {
						if(minutiPrvogKraj > minutiDrugogPocetak) {
							return new Vreme((minutiDrugogPocetak/60)%24, minutiDrugogPocetak%60);
						}
					}else {
						return new Vreme((minutiDrugogPocetak/60)%24, minutiDrugogPocetak%60);
					}
				}
				
				minutiPrvogPocetak += period.minuti();
				minutiPrvogKraj += period.minuti();
			} 
		
		
		return null;
	}



	
	

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	

}
