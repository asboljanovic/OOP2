package raspored;

public class Sema {
	
	private Vreme pocetak, kraj;
	private String naziv;
	
	private static class Elem {
		Sadrzaj s;
		Elem sled;
		Elem ( Sadrzaj ss) { s = ss; }
	}
	
	private Elem prvi, posl;
	
	public Sema (String n, Vreme p , Vreme k) {
	naziv = n ; pocetak = p; kraj = k;
	}
	
	public Sema(String n) throws GVreme {
		naziv = n;
		pocetak = new Vreme (8,0);
		kraj = new Vreme (22, 0);
	}
	
	public int trajanjeSeme()  {
			
	   return kraj.minuti() - pocetak.minuti();
		
	}
	
	
	
	
	
	
	public Sema dodaj(Sadrzaj s) throws GDodaj, GVreme {
		
		//grub nacrt algoritma
		//ovo sve kroz while(uslov u while-u dok nije kraj programa, ili kad zavrsis radices return da ti izadje samo, pogledaj preklapaSe)
		//-proveris pocetak
		//	-ako se uklapa i ima mesta top, samo dodas
		//		-ako se uklapa pocetak ali nema mesta, vidis da li mozes negde drugde da ga ubacis, ako moze top, ako ne ne moze
		//	-ako se ne uklapa a ima mesta, dodas gde ima mesta
		//pred kraj vajla dodas vreme (period) i tera sve samo
		//  
		//kul bi bilo da se napravi metoda koja ubacuje Elem u listu sortirano po vremenu pocetka
		Elem novi = new Elem(s);
		
		    
		    if (!(novi.s instanceof Ponavljajuci)) {
		if (prvi == null) {
			 if (novi.s.dohvTrajanje().minuti() > trajanjeSeme() ) {   throw new GDodaj();}
			 if (novi.s.dohvPocetak().minuti() < pocetak.minuti()) { throw new GDodaj(); }
			 if (novi.s.dohvPocetak().minuti() > kraj.minuti()) { throw new GDodaj(); }	
			 if (novi.s.krajnjeVremeSadrzaja().minuti() > kraj.minuti()) { throw new GDodaj(); }
			 prvi= novi;
			 
		
		   } else {
			   if (zauzeto() == trajanjeSeme()) { throw new GDodaj(); }
			   if (novi.s.dohvTrajanje().minuti() > zauzeto() ) {   throw new GDodaj();}
			   if (novi.s.dohvPocetak().minuti()< pocetak.minuti()) { throw new GDodaj(); }
			   if (novi.s.dohvPocetak().minuti() > kraj.minuti()) { throw new GDodaj(); }
			   if (novi.s.krajnjeVremeSadrzaja().minuti() > kraj.minuti()) { throw new GDodaj(); }
			   
			   Elem tek = prvi;
	            while(tek != null){
	            	
	            	int p = 1;
	            	while (novi.s.preklapaSe(tek.s) != null && p != 0) {
	            		novi.s.pomeri(new Vreme(0,15));
	            		p = 0;
	            	}
	            	if (p == 0) {
	            		tek = prvi;
	            	}else {
	            		tek = tek.sled;
	            	}
	            	
	            }
				 if (novi.s.krajnjeVremeSadrzaja().minuti() > kraj.minuti()) { throw new GDodaj(); }
			   
			   posl.sled = novi;  
			   
				} 
	
		       posl = novi;
				
				
				
				
		    } else { 
		    	if (zauzeto() == trajanjeSeme()) { throw new GDodaj(); }
		    	if(novi.s.dohvPocetak().minuti() < pocetak.minuti()) novi.s.postaviPocetno(pocetak);
		    	

		    	
		    	if (prvi == null) {   
		    		 if (novi.s.dohvTrajanje().minuti() > trajanjeSeme() ) {   throw new GDodaj();}	
		    		 if(novi.s.krajnjeVremeSadrzaja().minuti()> kraj.minuti()) {   throw new GDodaj();}
		    		
		    		 prvi = novi;		    		
		    		
		    	} else {
		    		 if (novi.s.dohvTrajanje().minuti() > zauzeto() ) {   throw new GDodaj();}	
		    		 if(novi.s.krajnjeVremeSadrzaja().minuti()> kraj.minuti()) {   throw new GDodaj();}
		    		 
		    		 	Elem tek = prvi;
		    	            while(tek != null){
		    	            	
		    	            	int p = 1;
		    	            	while (novi.s.preklapaSe(tek.s) != null && p != 0) {
		    	            		novi.s.pomeri(new Vreme(0,15));
		    	            		p = 0;
		    	            	}
		    	            	if (p == 0) {
		    	            		tek = prvi;
		    	            	}else {
		    	            		tek = tek.sled;
		    	            	}
		    	            	
		    	            }
		    		
		    			posl.sled = novi;
		    			
		    		}
				    		posl = novi;
		    	}
		    
		    
		    //SORTIRANJE 
		    for(Elem tek = prvi; tek!= posl; tek= tek.sled) {
				for(Elem tek2 = tek.sled; tek2!= null; tek2 = tek2.sled) {
					if (tek.s.dohvPocetak().minuti()  > tek2.s.dohvPocetak().minuti()) {
						Sadrzaj ss = tek.s;
						tek.s = tek2.s;
						tek2.s = ss;
					}
				
					
					
				} }
			
			return this;
				
				
			} 
		
		
		public int broj()  {
			int b =0;
			for(Elem tek = prvi; tek!= null; tek = tek.sled) b++;   
				
		
			return b;
		}
		
		
		
		
		
		
		public int zauzeto() throws GVreme {
			int s = 0;
			for(Elem tek = prvi; tek!= null; tek=tek.sled) {
				if (tek.s instanceof Ponavljajuci) {
					
					int vremeTekuceg = tek.s.krajnjeVremeSadrzaja().minuti();
					while(vremeTekuceg <= kraj.minuti()) {
						s+= tek.s.dohvTrajanje().minuti();
						vremeTekuceg += ((Ponavljajuci)tek.s).dohvPeriod().minuti();
					}
					
					
					
				}else s += tek.s.dohvTrajanje().minuti();
		}
			return s;}
	
	
	
	public double zauzetost() throws GVreme {
		double s = 0;
		for(Elem tek = prvi; tek!= null; tek=tek.sled) {
			
			if (tek.s instanceof Ponavljajuci) {
				
				int vremeTekuceg = tek.s.krajnjeVremeSadrzaja().minuti();
				while(vremeTekuceg <= kraj.minuti()) {
					s+= tek.s.dohvTrajanje().minuti();
					vremeTekuceg += ((Ponavljajuci)tek.s).dohvPeriod().minuti();
				}
				
				
				
			}else s += tek.s.dohvTrajanje().minuti();

			
		
		}
		
		return  (double)(s/trajanjeSeme())* 100.0;
	}
	
	public Sadrzaj dohvati(int i ) throws GIndeks {
		if (i < 0 || i > broj()) throw new GIndeks();
		int s = 0;
		for(Elem tek = prvi; tek!=null; tek=tek.sled) {
		
		if(s == i ) return tek.s;
		s++;
		}
		return null;
		
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(naziv + ":" + pocetak + "-" + kraj + "\n");
		for (Elem tek = prvi; tek != null; tek = tek.sled) {
			sb.append(tek.s + "\n");
		}
		return sb.toString();
		
	}

}
