package raspored;

public class GIndeks extends Exception {

	
	public String toString() {
		return " GRESKA ! PREKORACENJE INDEKSA! ";
	}
}
