package raspored;

public class GVreme extends Exception {
	
	public String toString() {
		return "GRESKA! PREKORACENJE!";
	}

}
