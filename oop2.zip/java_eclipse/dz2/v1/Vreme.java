package raspored;

public class Vreme {
	
	private int min, sat;
	
	
	public Vreme(int s , int m) throws GVreme {
		if(s > 23 || s < 0 || m > 59 || m <0 || (m%15) != 0 ) throw new GVreme();
		sat = s; min = m;		
			
	}
	
	public Vreme() { min = 0; sat = 0; }
	
	public boolean jednako(Vreme v) {
		if (sat == v.sat && min == v.min) return true; 
		else return false;
	}
	public int minuti() { return min+ sat*60; }
	
	public static  Vreme saberi( Vreme v1 , Vreme v2) throws GVreme  {
		int s = 0,  m = 0;
		s = (v1.sat + v2.sat)%24;
		 if ((v1.min + v2.min) >= 60) {
			 s = (s+1)%24;
		
		 }  
		 m = (v1.min + v2.min)%60;
		 
		 return new Vreme(s,m);	
		 
		
		
		
	}
	
	public String toString() {
		return "(" +  sat + ":" + min + ")";
	}

	public boolean equals(Object v) {
		if (v == null) return false;
	    if (v == this) return true;
	    if (!(v instanceof Vreme)) return false;
	    Vreme vv = (Vreme)v;
	    if (sat == vv.sat && min == vv.min) return true; 
		else return false;
	    
	}
	

}
