package karting;

public class Krivina extends Specificnost implements Cloneable   {
	
	
	private double max;
	
	
	
	public Krivina (double m) {
	    super();
		max = m;
		
	}
	
	public double maksBrzina() { return max; }

	
	public void ispoljiEfekat(Object o) throws GNeodgovarajuciObjekat {
		if ( !  (o instanceof Vozilo) ) throw new GNeodgovarajuciObjekat();
		Vozilo v= (Vozilo)o;
		if (max < v.dohvMaksBrzinu()) {
			v.postStariMax();
			v.postMaksBrzinu(max*v.dohvUpravljivost());
		}

	} 

	public void ponistiEfekat(Object o) throws GNeodgovarajuciObjekat {
		if ( !  (o instanceof Vozilo) ) throw new GNeodgovarajuciObjekat();
		Vozilo v = (Vozilo)o;
		if(v.dohvStariMax() != 0) {
		v.postMaksBrzinu(v.dohvStariMax());
		}

	} 
	
	
	
	
	public Krivina clone() {
		
		try {
			
			Krivina kopija = (Krivina)super.clone();
			kopija.postId(++posId);
			return kopija;
			
			
		}catch(CloneNotSupportedException e) { return null; }
		
	} 
	
	
	
	
	
	public String toString() {
		return "K" + max;
	} 

	

}
