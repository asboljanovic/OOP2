package karting;

public class Vozilo {
	
	
	private double max,a,u , v, stariMax = 0;
	private String ime;
	
	public Vozilo (double m , double aa , double uu , String i) {
		
		max = m ; a = aa; u = uu; ime = i;
		
		v = 0;
	}
	
	public double dohvMaksBrzinu() { return max; }
	public double dohvUbrzanje() { return a; }
	public double dohvUpravljivost() { return u; }
	public String dohvIme() { return ime; }
	public double dohvTrenBrzinu() { return v; }
	
	public double dohvStariMax() { return stariMax; }
	public void postStariMax() { stariMax = max; }
	public void postMaksBrzinu(double m) { max = m;
	if ( v > max) v = max; }
	public void postUbrzanje(double m) { a = m; }
	public void postUpravljivost(double m) {  if (m >= 0 &&  m <=1 ) u = m; }
	public void postIme(String i) { ime = i; }
	public void postTrenBrzinu(double vv) { v = vv; if (v > max) v = max; } 
	
	 public String toString() {
		return  ime + "[" + max + "," + a + "," + u + "]";
	} 
	
	public double  pomeriVozilo(double t ) {
       double  vremeDostizanjaMax = (max -v)/a;
				
		
		double vremeKonstantneBrzine = 0;
		if(t> vremeDostizanjaMax) {
			vremeKonstantneBrzine =t - vremeDostizanjaMax;
			double s = vremeKonstantneBrzine * max;
			double putSaUbrzanjem = v*vremeDostizanjaMax + a*Math.pow(vremeDostizanjaMax, 2)/2;
			postTrenBrzinu(max);
			return s + putSaUbrzanjem;
			
			
			
		} else { 
			double putSaUbrzanjem = v*t + a*Math.pow(t, 2)/2;
			postTrenBrzinu(Math.sqrt(Math.pow(v, 2)+2*a*putSaUbrzanjem));		
			return putSaUbrzanjem;
		}
	 }
		
			

	
	public double izracunajVreme(double  s) {
		double  vremeDostizanjaMax = (max -v)/a;
		double maxPutSaUbrzanjem = (max*max - v*v )/(2*a);
		
		
		if(maxPutSaUbrzanjem < s ) {
			double konstPut = s - maxPutSaUbrzanjem;
			double vremeKonstantnogPuta = konstPut/max;
			return vremeKonstantnogPuta+ vremeDostizanjaMax;
			
			
			
			
			
		} else  { 
        		double vv = Math.sqrt(v*v + 2*a*s);
 
    			return (vv -v)/a;
		} 
			
		
		
		
		 } 
	
	
	
	
	
	
	
	
	
	

}
