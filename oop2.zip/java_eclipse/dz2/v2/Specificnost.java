package karting;

public abstract class Specificnost implements Cloneable{

	protected static int posId = 0;
	
	private int id;
	
	public Specificnost() {
		id = ++posId;
	}
	

	
	public Specificnost clone() throws CloneNotSupportedException {
		return (Specificnost) super.clone();
	}
	public int dohvatiId() { return id; }
	public void postId (int i) { id = i; }
	                  
	public  abstract void   ispoljiEfekat(Object o) throws GNeodgovarajuciObjekat;
	
	public abstract void ponistiEfekat(Object o) throws GNeodgovarajuciObjekat;
	
	
}
