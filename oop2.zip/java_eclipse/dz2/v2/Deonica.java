package karting;

public class Deonica  implements Cloneable  {
	
	
	
	private double duz;
	private static class Elem implements Cloneable {
		Specificnost s;
		Elem sled;
		
		protected Elem clone() {
			try {
				Elem e =  (Elem ) super.clone();
                     e.s = s;
				
                     return e;						
				
				
			}catch(CloneNotSupportedException e) { return null; }
			
		}
		
		Elem(Specificnost ss) { s= ss; }
	}
	private Elem prvi , posl;
	
	public Deonica (double d) {
		
		duz = d;
	}
	
	public double duzina() { return duz; }
	
	public Deonica dodajSpecificnost(Specificnost s) {
		Elem novi = new Elem(s);
		if (prvi == null) prvi = novi;
		else posl.sled = novi;
		posl = novi;
		return this;
	}
	
	public Deonica izbaciSpecificnost (int id) {	
		   
		 Elem tek = prvi;
		 if(tek.s.dohvatiId() == id) {
			 prvi = prvi.sled;
			 return this;
		 } else {
		  while(  tek.sled != null && tek.sled.s.dohvatiId()!= id) {
			  tek = tek.sled;
		  }
		 if (tek.sled == null) { return this; }
		 else {
		  tek.sled  = tek.sled.sled; 
		  return this;
		 }
		 } }
	
	
	public Specificnost dohvSpecificnost (int k)
	{
		int i= 0;
	 for(Elem tek =prvi;tek!= null; tek = tek.sled ) 
	 {	 if (k == i) return tek.s;
	 i++; } 
	 return null;
		
	}
	
	public int brojSpecificnosti() { int b= 0;
	for(Elem tek =prvi;tek!= null; tek = tek.sled ) b++;
	return b;		
	}
	
	public Deonica clone() throws CloneNotSupportedException {
		
		try {
			Deonica d =  (Deonica ) super.clone();
			d.prvi = prvi.clone();
		    d.posl = posl.clone();
		    d.prvi.s = prvi.s.clone();
		    d.posl.s = posl.s.clone();
			
			
			
		
		return d;
	
		
					
					
			
			
		}catch(CloneNotSupportedException e) { return null; }
	}
	
	
	
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("deonica(" + duz + "m)");
		for(Elem tek =prvi;tek!= null; tek = tek.sled ) sb.append(tek.s);
		return sb.toString();
	}
	
	
	
	
	
	

}
