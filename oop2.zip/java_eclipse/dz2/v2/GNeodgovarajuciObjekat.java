package karting;

public class GNeodgovarajuciObjekat extends Exception {
	
	public String toString() {
		return "GRESKA! NEODGOVARAJUCI OBJEKAT!";
		
	}

}
