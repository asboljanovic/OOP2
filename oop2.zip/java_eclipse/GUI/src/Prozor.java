import java.awt.*;

public class Prozor extends Frame {
	
	public Prozor() {
		super("IME PROZOR"); //ime koje ce biti na vrhu;
		setSize(999,999);
		setVisible(true);
	}
	
	public void paint(Graphics g ) {
		g.drawString("HELLO WORLD", 555, 560);

		
		g.drawLine(222, 202, 220, 202);
	}
	
	public boolean handleEvent(Event e) {
		if ( e.id == Event.WINDOW_DESTROY) {
			System.exit(0);
			return true;
		} else return false;
	}
	
	

}
