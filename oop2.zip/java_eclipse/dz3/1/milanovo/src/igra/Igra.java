package igra;

import java.awt.*;
import java.awt.event.*;



public final class Igra extends Frame {

	private Basta basta = new Basta(4,4);
	private Button dgm = new Button("Kreni") ;
	private Checkbox rdgLako, rdgSrednje,rdgTesko;
	PanelListener listener = new PanelListener();

	public Igra() {
		super("Igra");
		setSize(600,600);
		dodajProzor();
		dodajListenere();
		setVisible(true);
		
	}
	
	public void azuriraj() {
		 for(int i = 0 ; i< basta.vrs; i++)
			  for(int j = 0; j < basta.kol; j++) {
				  if(basta.matrica[i][j].dohvZivotinju()!= null) {
				  
					  basta.matrica[i][j].postaviZivotinju(null); basta.matrica[i][j].repaint();
				  } }
		 basta.kolicinaPovrca = 100;
	}
	
	public Igra dohvatiIgru() {
		return this;
	}

	private void dodajListenere() {
		 for(int i = 0 ; i< basta.vrs; i++)
			  for(int j = 0; j < basta.kol; j++)
				  basta.matrica[i][j].addMouseListener(listener);
		 
		 
		 
		 
		 
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				dispose(); basta.zavrsi();
				
				
			}
		});
	}

	public void azuriraj(boolean traje) {
		rdgLako.setEnabled(!traje);
		rdgSrednje.setEnabled(!traje);
		rdgTesko.setEnabled(!traje);		
	}

	private void dodajProzor() {
		add(basta, "Center");
		Panel plo = new Panel(new GridLayout(0,1));

		//LABELA SA NATPISOM
		Label label = new Label("Tezina:");
		label.setFont(new Font("Serif", Font.BOLD, 14));
		plo.add(label, "North");

		//CHECKBOX
		CheckboxGroup grp = new CheckboxGroup();
		plo.add(rdgLako = new Checkbox("Lako", grp,false));
		plo.add(rdgSrednje = new Checkbox("Srednje", grp,true));
		plo.add(rdgTesko = new Checkbox("Tesko", grp,false));
		ItemListener osluskivacCheckbox = new ItemListener() {

			public void itemStateChanged(ItemEvent dog) {
				if((Checkbox)dog.getSource() == rdgLako) {
					basta.postaviInterval(1000);
					basta.postBrKoraka(10);
				}else if ((Checkbox)dog.getSource() == rdgSrednje) {
					basta.postaviInterval(750);
					basta.postBrKoraka(8);
				}else {
					basta.postaviInterval(500);
					basta.postBrKoraka(6);
				}
			}

		};
		rdgLako.addItemListener(osluskivacCheckbox);
		rdgTesko.addItemListener(osluskivacCheckbox);
		rdgSrednje.addItemListener(osluskivacCheckbox);


		//DUGME
		plo.add(dgm);
		dgm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(dgm.getLabel()=="Kreni") {
					azuriraj(true);
					basta.kreni();
				}
				else {
					basta.stani();
					azuriraj();
					azuriraj(false);
				}
				if(dgm.getLabel() == "Kreni") {
					dgm.setLabel("Stani"); } else dgm.setLabel("Kreni");
			}

		});
  
		

		Panel p = new Panel();
		//LABELA SA POVRCEM
		Label labela2 = new Label("Povrce: 0" );
		basta.postaviLabelu(labela2);
		labela2.setFont(new Font("Serif", Font.BOLD, 14));
		p.setLayout(new BorderLayout());
		p.add(labela2);
		Panel konacni = new Panel();
		konacni.setLayout(new GridLayout(0,1));
		konacni.add(plo);
		konacni.add(p);
		
		add(konacni, "East");

				
	}
	private class PanelListener implements MouseListener {

	       
        public void mouseClicked(MouseEvent event) {
                   
                
        
        }

        @Override
        public void mouseEntered(MouseEvent arg0) {}

        @Override
        public void mouseExited(MouseEvent arg0) {}

        @Override
        public void mousePressed(MouseEvent event) {
        	  Object source = event.getSource();
              Rupa poljePressed = (Rupa) source;
              poljePressed.zgaziRupu();
        	
        	
        	
        }

         public void mouseReleased(MouseEvent arg0) {
        	 
   			  }
       

    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	public static void main(String[] args) {
		new Igra();
	}


}
