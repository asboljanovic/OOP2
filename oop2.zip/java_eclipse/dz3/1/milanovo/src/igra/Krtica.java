package igra;
import java.awt.*;

public class Krtica extends Zivotinja {
	public Krtica(Rupa r) {
		super(r);
	}

	public void efekatUdareneZivotinje() {
		   udaren = true;
			  rupa.zaustavi();
			rupa.repaint();
	}

	public void efekatPobegleZivotinje() {
		rupa.basta.smanjiKolPovrca();
		
	}

	public void crtaj() {
		Graphics g = rupa.getGraphics();
		g.setColor(Color.DARK_GRAY);
		int n = rupa.dohvBrKoraka();
		int sir = rupa.getWidth();
		int vis = rupa.getHeight();
		int sirina = sir/n;
		int visina = vis/n;

		if(n != 0) {
			g.fillOval(sir/2 - sirina/2, vis/2- visina/2, sirina, visina);
			
		} 
	}

}
