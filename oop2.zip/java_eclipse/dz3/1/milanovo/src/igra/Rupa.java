package igra;

import java.awt.*;

public class Rupa extends Canvas implements Runnable {
	private  Zivotinja zivotinja;
	protected Basta basta;
	private Thread nit;
	private boolean radi = false;
	private int brKoraka;

	public Rupa(Basta b) {
		basta = b;
	}

	public void run() {
		try {
			while(!Thread.interrupted()) {
				synchronized(this) {
					if(!radi) wait();
				}

				while( dohvBrKoraka()> 0) {
					repaint();
					Thread.sleep(100);
					postaviBrKoraka(dohvBrKoraka() -1);

				}
				postaviBrKoraka(basta.dohvBrKoraka());
				slobodnaRupa();
				Thread.sleep(2000); 
				if(zivotinja != null) {
				if(zivotinja.udaren == false) zivotinja.efekatPobegleZivotinje();
				}
				zaustavi();
				repaint();
			}
		}catch(InterruptedException e) {}
	}

	public synchronized void stvoriNit() {
		nit = new Thread(this);
		nit.start();
	}

	public void postaviZivotinju(Zivotinja z) {
		zivotinja = z;
	}

	public  Zivotinja dohvZivotinju() {
		return zivotinja;
	}

	public synchronized void stani() {
		radi = false;
		notifyAll();
	}
	public synchronized void kreni() {
		radi = true;
	}

	public synchronized void slobodnaRupa() {
		if (zivotinja == null) notifyAll();
	}

	public synchronized void zaustavi() {
		zivotinja = null;
		nit.interrupt();
	}

	public boolean pokrenutaNit() {
		return radi;
	}

	public void postaviBrKoraka(int b) {
		brKoraka = b;
	}

	public int dohvBrKoraka()  {
		return brKoraka;
	}

	public  synchronized void zgaziRupu() {
		if(zivotinja == null) return;
		zivotinja.efekatUdareneZivotinje();
	}

	public synchronized void paint(Graphics g) {
		setBackground(new Color(153, 102,0));
		if(zivotinja != null) {
			zivotinja.crtaj(); 
		}
	}

}
