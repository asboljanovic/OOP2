package igra;

public abstract class Zivotinja {
	protected Rupa rupa;
	protected boolean udaren = false;
	
	public Zivotinja(Rupa r) {
		rupa = r;
	}
	
	public abstract void efekatUdareneZivotinje();
	public abstract void efekatPobegleZivotinje();
	public abstract void crtaj();
}
