package igra;

import java.awt.*;

public class Basta extends Panel implements Runnable {
	protected int kolicinaPovrca = 1;
	protected int vrs, kol;
	protected Rupa[][] matrica;
	protected static int brKoraka;
	private long interval;
	private Thread nit = new Thread(this);
	private boolean radi = false;
	private Label labela;

	public Basta(int v, int k) {
		vrs = v; kol = k;
		setBackground(new Color(0,204,0));	

		setLayout(new GridLayout(v,k,40,40 ));
		kolicinaPovrca= 100;
		matrica = new Rupa[v][k];
		dodajPolja();
		nit.start();
	}

	private void dodajPolja() {
		for(int i =0 ; i< vrs; i++)
			for(int j = 0; j < kol; j++) {
				matrica[i][j] = new Rupa(this);
				add(matrica[i][j]);matrica[i][j].repaint();
				repaint();

			}			
	}	

	public int dohvBrKoraka() {
		return brKoraka;
	}
	
	public void postBrKoraka(int b) {
		for(int i = 0 ; i < vrs; i++)
			for(int j = 0; j < kol; j++)
				matrica[i][j].postaviBrKoraka(b);
		brKoraka = b;
	}
	public void smanjiKolPovrca() {
		kolicinaPovrca--;
	}

	public synchronized void kreni() {
		radi = true; notifyAll();
	}
	public synchronized void stani() {
		radi = false; notifyAll();
	}
	
	public void zavrsi() {
		nit.interrupt();
		for(int i =0 ; i< vrs; i++)
			for(int j = 0; j < kol; j++)
				if(matrica[i][j].pokrenutaNit()) {
				matrica[i][j].zaustavi(); }
		
	}
	
	public void postaviInterval(long i) {
		interval = i;
	}


	public void postaviLabelu(Label l) {
		labela  = l;		
		labela.setFont(new Font("Serif", Font.BOLD, 14));
	}

	private synchronized void azurirajLabelu() {
		if (labela == null) return;
		labela.setText("Povrce: "  + kolicinaPovrca);
		
	}

	public synchronized void dodajKrtice() throws InterruptedException {
		boolean nijeNadjen = true;

		while(nijeNadjen) {
			int i = (int) (Math.random() * vrs);
			int j = (int) (Math.random() * kol);

			if(matrica[i][j].dohvZivotinju() == null ) {

				matrica[i][j].postaviZivotinju(new Krtica(matrica[i][j]));

				matrica[i][j].stvoriNit();
				matrica[i][j].kreni();
				interval -=interval/100; }
			nijeNadjen = false;
		}
	}
	public synchronized void proveraPovrca() {
		if (kolicinaPovrca == 0) zavrsi();
	}

	public void run() {
		try {
			while(!Thread.interrupted()) {
				synchronized(this) {
					if(!radi) wait();
				}
				dodajKrtice();
				azurirajLabelu();
				proveraPovrca();
				Thread.sleep(interval);
			}
		}catch(InterruptedException g) {}
	}

}
