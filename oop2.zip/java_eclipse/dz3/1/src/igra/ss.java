package igra;

public interface ss {

}
