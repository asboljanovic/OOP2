package igra;

import java.awt.*;
import java.awt.event.*;

public class Igra extends Frame {
	
	private Basta basta = new Basta(4,4);
	private Button dgm = new Button("Kreni") ;
	private Checkbox rdgLako, rdgSrednje,rdgTesko;

	
	
	
	
	public Igra() {
		super("Igra");
		setSize(600,600);
		dodajProzor();
		dodajListenere();
		setVisible(true);
		basta.postBrKoraka(10);
		basta.postaviInterval(100);
		basta.kreni();
		
	}
	
	private void dodajListenere() {
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {

				dispose();
			}
		});
	}
	
	public void azuriraj(boolean traje) {

		rdgLako.setEnabled(!traje);
		rdgSrednje.setEnabled(!traje);
		rdgTesko.setEnabled(!traje);
		
	}

	private void dodajProzor() {
		add(basta, "Center");
		Panel plo = new Panel(new GridLayout(0,1));
		
		//LABELA SA NATPISOM
		Label label = new Label("Tezina:");
		label.setFont(new Font("Serif", Font.BOLD, 14));
		plo.add(label, "North");
		
		//CHECKBOX
		CheckboxGroup grp = new CheckboxGroup();
		plo.add(rdgLako = new Checkbox("Lako", grp,false));
		plo.add(rdgSrednje = new Checkbox("Srednje", grp,true));
		plo.add(rdgTesko = new Checkbox("Tesko", grp,false));
	    ItemListener osluskivacCheckbox = new ItemListener() {

			
			public void itemStateChanged(ItemEvent dog) {
				if((Checkbox)dog.getSource() == rdgLako) {
					basta.postaviInterval(1000);
					basta.postBrKoraka(10);
				}else if ((Checkbox)dog.getSource() == rdgSrednje) {
					basta.postaviInterval(750);
					basta.postBrKoraka(8);
				}else {
					basta.postaviInterval(500);
					basta.postBrKoraka(6);
				}
			}
	    	
	    };
	    rdgLako.addItemListener(osluskivacCheckbox);
	    rdgTesko.addItemListener(osluskivacCheckbox);
	    rdgSrednje.addItemListener(osluskivacCheckbox);
		
		
		//DUGME
		plo.add(dgm);
		dgm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(dgm.getLabel()=="Kreni") {
				azuriraj(true);
				basta.kreni();
				}
				else {
					basta.zavrsi();
					azuriraj(false);
				}
				if(dgm.getLabel() == "Kreni") {
				dgm.setLabel("Stani"); } else dgm.setLabel("Kreni");
			}
			
		});
		
		
		//LABELA SA POVRCEM
		Label labela2 = new Label("Povrce: 0" );
		basta.postaviLabelu(labela2);
		labela2.setFont(new Font("Serif", Font.BOLD, 14));
		plo.add(labela2);
		
		
		
		
		add(plo, "East");
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		             new Igra();
		 }

	

}
