package baloni;
import java.awt.*;



public abstract class KruznaFigura extends Krug {

	
	protected Vektor brzina;
	protected Scena scena;
	protected boolean preklopioSe = false;

	
	public enum Smer { LEVO, DESNO, GORE , DOLE  }
	
	public KruznaFigura(Vektor c, Color b, double r, Vektor brz, Scena s) {
		super(c,b,r);
		brzina = brz;
		scena = s;
	
		
	}
	

	
	
	
	
	protected abstract void crt (Graphics g , double x, double y);
	
	public abstract void crtaj(Scena s);
	public abstract void pomeri(Smer s); 
	
	

    
	
	public synchronized boolean sudarioSe(KruznaFigura f) {
		return this.preklapajuSe(this, f);
	}

	

}
