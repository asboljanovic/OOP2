package baloni;



public class Vektor implements Cloneable {
	private double x,y;
	
	public Vektor(double xx, double yy) {
		x = xx; y = yy;
	}
	
	public Vektor clone() {
		
		try {
			Vektor v = (Vektor)super.clone();
			v.x = x;
			v.y = y;
			return v;
			
		}catch (CloneNotSupportedException e)
		{ e.printStackTrace(); }
		return null;

	}
	
	public double dohvX() { return x; }
	public double dohvY() { return y; }
	
	public Vektor pomnozi(double r) {
		this.x *= r;
		this.y *= r;
		return this;
	}
	
	public Vektor saberi(Vektor v) {
	
	     x = x + v.x;
	     y = y +v.y;
		return this;
	}
	public static double d(Vektor t1, Vektor t2) {
		return Math.sqrt(Math.pow(t1.dohvX() - t2.dohvX(), 2)
		+ Math.pow(t1.dohvY() - t2.dohvY(), 2));
		}
	
	
	

}
