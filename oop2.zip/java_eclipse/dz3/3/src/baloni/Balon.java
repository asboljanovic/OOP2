package baloni;

import java.awt.*;


public class Balon extends KruznaFigura {
	
private  boolean napravljen = true;
private long t0 ;
 
	


	public Balon(Vektor c, Color b, double r, Vektor brz, Scena s) {
		super(c,b,r,brz,s);
		b = Color.RED;
		t0 = System.currentTimeMillis();
	}
	

	protected void crt(Graphics g, double x, double y) {
		g.setColor(this.boja);
		g.fillOval((int)(x-this.r/2),(int)( y-this.r/2),(int) r,(int) r);

	}
	
	public void crtaj(Scena s) {
		
		int sir = s.getWidth();
		int vis = s.getHeight();
		
		if(this.centar.dohvX() >= 0 && this.centar.dohvX() <= sir && this.centar.dohvY() >=0 && this.centar.dohvY() <=vis ) {
			if(napravljen) {
				int y = 0;
				int x = (int) (s.getWidth()* Math.random());
				this.centar = new Vektor(x,y);
				
				napravljen = false;
				
			}
			Graphics g = s.getGraphics();
			g.setColor(this.boja);
			crt(g,this.centar.dohvX(),this.centar.dohvY()); } else {
				s.izbaci(this);
			}
		
		
	}

	
	public void pomeri(Smer ss) {
		if(scena.prosloOdredjenoVreme ){
		
		double t =  (double)((System.currentTimeMillis() - t0)/1000.);
		
            Vektor v = new Vektor(this.brzina.dohvX(), this.brzina.dohvY());
            
		    v.pomnozi(t);
			this.centar.saberi(v); 
	        
	
	} 
	}
	
	

}
