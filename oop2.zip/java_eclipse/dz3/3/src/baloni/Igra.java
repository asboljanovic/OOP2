package baloni;
import java.awt.event.*;

import baloni.KruznaFigura.Smer;

import java.awt.*;

public class Igra extends Frame {
	
	private Scena scena;
	
	public Igra() {
		super("Baloni");
		setSize(600,600);
		scena=  new Scena(this);
		setLayout(new GridLayout());
		add(scena );
		dodajListenere();
		setVisible(true);
		
		
		scena.kreni();
		requestFocus();
	}
	
	
	
	
	private void dodajListenere() {

		scena.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				switch(e.getKeyCode()) {
				case KeyEvent.VK_LEFT: 
					
					scena.pomeri(Smer.LEVO);break;
					case KeyEvent.VK_RIGHT:
				    scena.pomeri(Smer.DESNO);
					break;
				
				}
				
			}
		});
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent dog) {
				scena.zavrsi();
				dispose();
			}
		});
		
		
}
	

	public static void main(String[] args) {
		new Igra();

	}

}
