package baloni;
import java.awt.*;

public abstract class Krug {
	
	
	protected Vektor centar;
	protected Color boja;
	protected double r;
	
	
	public Krug(Vektor c, Color b, double r) {
		centar =c ;
		boja = b;
		this.r = r;
		
	}
	public   boolean preklapajuSe(Krug k1,	Krug k2) {
		
			return (k1 != null) && (k2 != null) &&
			(Vektor.d(k1.centar, k2.centar) < (k1.r/2 + k2.r/2));
			}
	
	
	public abstract void crtaj(Scena s);
	
	
	
	
		
		
		
	
	
	


}
