package baloni;

import java.awt.Color;
import java.awt.Graphics;

public class Igrac extends KruznaFigura {

	private int pomeraj;
	public Igrac(Vektor c, Color b, double r, Vektor brz, Scena s, int pom) {
		super(c, b, r, brz, s);
		pomeraj = pom;
		
	}
	
	

  
	
	

	
	

    public boolean moze(Smer s) {
    	if (s == Smer.GORE || s== Smer.DOLE) return false;
    	else if(s == Smer.LEVO) {
    		if(this.centar.dohvX() - pomeraj < 0) return false;
    	}else if (s == Smer.DESNO)
    	{
    		if(this.centar.dohvX() + pomeraj >= scena.getWidth()) return false;
    	}
    		return true;
    	
    	
    }
  
	
	public void pomeri(Smer s) {
		if (moze(s)) {
			if(s  == Smer.LEVO)
			{
			
			this.centar.saberi(new Vektor(-pomeraj, 0));
			}
			else if (s == Smer.DESNO) {
				
			this.centar.saberi(new Vektor(pomeraj, 0));	}
		
		
		
	}
	}



	
	public void crtaj(Scena s) {
		int sir = s.getWidth();
		
		
		if(this.centar.dohvX() >= 0 && this.centar.dohvX() < sir ) {

			Graphics g = s.getGraphics();
			g.setColor(this.boja);
			crt(g,this.centar.dohvX(),this.centar.dohvY()); }
		
		
	}
	public void crt(Graphics g, double x, double y) {
		g.fillOval((int)(x-this.r/2),(int) (y-this.r/2),(int) r, (int)r);
		g.setColor(Color.BLUE);
		g.fillOval((int)(x-this.r/4),(int) (y-this.r/4),(int) r/2, (int)r/2);
		

	}









	
	

}
