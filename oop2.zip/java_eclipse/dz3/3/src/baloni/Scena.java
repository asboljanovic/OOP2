package baloni;

import java.awt.*;

import baloni.KruznaFigura.Smer;

public class Scena extends Canvas implements Runnable{
	
	
	
	private Igra igra;
	private Thread nit = new Thread(this);
	private boolean radi = false;
	protected Igrac igrac;
	protected long t0;
	protected  boolean prosloOdredjenoVreme = false;
	public  double protekloVreme;
	
	
	private Elem prvi , posl;
	
	private class Elem{
		KruznaFigura kf;
		Elem sled;
		Elem(KruznaFigura kff) {
			kf = kff;
			if(prvi == null) prvi = this;
			else posl.sled = this;
			posl =this;
			
		}
	}
	
	public synchronized Scena dodaj(KruznaFigura f) {
		new Elem(f);
		return this;
	}
	public synchronized void izbaci(KruznaFigura f) {
		Elem tek = prvi, pret = null;
		while(tek!= null && tek.kf != f) { pret = tek; tek = tek.sled; }
		if(tek!=null) {
			if (pret == null) prvi = tek.sled; else pret.sled = tek.sled;
			if(tek.sled == null) posl = pret;
		}
	}
	
	
	
	public Scena(Igra i) {
		igra = i;
		t0 = (System.currentTimeMillis());
		nit.start();
	}
	
	public synchronized void prosloOdredjenoVreme(long t) {
		 
		if(System.currentTimeMillis()-t0 >= t)  { 
		prosloOdredjenoVreme = true; notifyAll();
			
		}
		
		
		
	
		
		
		
	}

	
	public synchronized void kreni() {
		radi = true; notifyAll(); repaint();
		
	}
	public void zavrsi() {
		nit.interrupt();
	}
	
	private synchronized void napraviIgraca() {
		if (igrac == null) { 
			  
			  Vektor c = new Vektor(this.getWidth()/2, this.getHeight() - 30);
			  Vektor v = new Vektor(10, 0);
			igrac = new Igrac(c , Color.GREEN , 30, v, this, 10);
			
				
			}
		requestFocus();
	}
	
	private synchronized void azurirajBalone() {
		 
				if (prosloOdredjenoVreme) {
					int verovatnoca = (int) (Math.random()*10);
					if ( verovatnoca == 1  ) {
				double x = this.getWidth()*Math.random();
		Vektor c = new Vektor(x,0);
		  Vektor v = new Vektor(Math.random(), Math.random());
		  Balon b = new Balon(c,Color.RED, 20, v, this);
		  dodaj(b);
		  
		   }
					
			
			} 
		
		
		
		
		for(Elem tek = prvi; tek != null; tek= tek.sled) {
			 
			  int xx = (int) (Math.random()*5);
			  Smer s = Smer.DOLE;
			  if(xx == 0) {
			   s = Smer.LEVO;
			  }else if(xx == 1) {
				  s = Smer.DESNO;
			
			  }else  {
				  s = Smer.DOLE;
			  }
			  
			  tek.kf.pomeri(s);
		  }
		
		
		
	}
	
	public synchronized void paint(Graphics g) {
		
		
		if(igrac != null) {
		igrac.crtaj(this); }
		if(prvi != null) {
			for(Elem tek = prvi; tek!= null; tek = tek.sled) tek.kf.crtaj(this);
		}
		
		
		
		
	}
	
	public synchronized void pomeri(Smer smer) {
		if(igrac == null) return;
		igrac.pomeri(smer);
		
		}

	
	public synchronized void proveraSudaranja() {
		if(igrac == null || prvi == null) return;
		for(Elem tek = prvi; tek!= null; tek = tek.sled) {
			if( tek.kf instanceof Balon) {
		if(igrac.sudarioSe(tek.kf)) zavrsi(); } }
		
			
			if(prvi.sled != null) {
			for(Elem tek1 = prvi;tek1 != posl; tek1 = tek1.sled)
				for(Elem tek2 = prvi.sled; tek2 != null; tek2 = tek2.sled ) {
					if (tek1.kf.preklapajuSe(tek1.kf, tek2.kf)) {
						
						tek1.kf.preklopioSe = true;
						tek2.kf.preklopioSe = true;
					}
				}
		}

			
		}
	
	
	public void run() {
		try {
			
			while(!Thread.interrupted()) {
			  synchronized(this) { if (!radi) wait(); }
			  prosloOdredjenoVreme(1000);
			  napraviIgraca();
			  azurirajBalone();
		 
			  repaint();
			  proveraSudaranja();
			
			  Thread.sleep(60);
			
			  prosloOdredjenoVreme = false;
				
				
			}
		}catch(InterruptedException g) {}
		
	}
}
