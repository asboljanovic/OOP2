package igra;

import java.awt.*;
import java.awt.event.*;



import igra.Figura.Smer;




public class Igra extends Frame  {
	
	protected  Mreza mreza;
	private Label podloga;
	protected Label poeni = new Label ("Poeni : 0" );
	private Panel panel = new Panel();
	private Panel jug = new Panel();
	private Checkbox trava, zid;
	protected TextField brojNovcica= new TextField("12");
	private Button pocni = new Button("Pocni");
	protected boolean rezimIgre = true;
	protected boolean rezimIzmene = false;
	 PanelListener listener = new PanelListener();
	 
	
	public Igra() {
	super("Igra");
		setSize(600 ,600);
		
		dodajMeni();
		
		mreza  = new Mreza(this);
		
		add(mreza, "Center");
		this.repaint();
		
		dodajIzborPodloge();
		dodajJuzniPanel();
		dodajListenere();
		setLocationRelativeTo(null);
		
		setVisible(true);
		
		
	}
	
	private void dodajJuzniPanel() {
		jug.setLayout(new GridLayout());
		Panel panel1 = new Panel();
		Panel panel2 = new Panel();
		
		Label novcic = new Label("Novcici :");
		novcic.setFont(new Font(null, Font.BOLD, 18));
		novcic.setAlignment(Label.CENTER);
		panel1.add(novcic);
		brojNovcica.setFont(new Font(null, Font.BOLD, 18));
		poeni.setFont(new Font(null, Font.BOLD, 18));
		pocni.setFont(new Font(null, Font.BOLD, 18));
		pocni.setSize(100, 50);
		panel1.add(brojNovcica);
		panel2.add(poeni);
		panel2.add(pocni);
		jug.add(panel1);
		jug.add(panel2);
		add(jug, "South");
		repaint();
		
		
		
	}
	private void dodajIzborPodloge() {
		podloga = new Label("Podloga:");
		podloga.setFont(new Font(null, Font.BOLD, 18));
		panel.setLayout(new GridLayout());
		panel.add(podloga, "West");
		Panel panel1 = new Panel();
		Panel panel2 = new Panel();
		Panel panel3 = new Panel();
		panel1.setBackground(Color.GREEN);
		panel2.setBackground(Color.LIGHT_GRAY);
		
		CheckboxGroup grp = new CheckboxGroup();
		panel1.setLayout(new CardLayout());
		panel2.setLayout(new CardLayout());
		panel1.add(trava = new Checkbox("Trava" , grp , true) );
		trava.setFont(new Font(null, Font.BOLD, 18));
		
		panel2.add(zid = new Checkbox("Zid" , grp , false));
		zid.setFont(new Font(null, Font.BOLD, 18));
		panel3.setLayout(new GridLayout(0,1));
		panel3.add(panel1, "North");
		panel3.add(panel2, "South");
		
		panel.add(panel3, "East");
		add(panel, "East");
		repaint();
		
		
	}
	

	private void dodajMeni() {
		MenuBar bar = new MenuBar();
		setMenuBar(bar);
		Menu meni = new Menu("Rezim");
		bar.add(meni);
		MenuItem izmena = new MenuItem("Rezim izmene", new MenuShortcut('N'));
		meni.add(izmena);
		
		MenuItem igranje= new MenuItem("Rezim igranje");
		meni.add(igranje);
		 igranje.addActionListener(new ActionListener() {
		        public void actionPerformed(ActionEvent ev) {
		        	 rezimIgre = true;
		        	   rezimIzmene = false;
		        	   brojNovcica.setEnabled(true);
		        	   pocni.setEnabled(true);
		        	   
		            
		        }
		    });
		 izmena.addActionListener(new ActionListener() {
		        public void actionPerformed(ActionEvent ev) {
		        	   rezimIgre = false;
		        	   rezimIzmene = true;
		               pocni.setEnabled(false);
		               brojNovcica.setEnabled(false);
		               mreza.stani();
		               azuriraj();
		               
		        }
		    });
		
		 repaint();
		
	}
	
	public class PanelListener implements MouseListener {

       
        public void mouseClicked(MouseEvent event) {
                   
                
        
        }

        @Override
        public void mouseEntered(MouseEvent arg0) {}

        @Override
        public void mouseExited(MouseEvent arg0) {}

        @Override
        public void mousePressed(MouseEvent event) {
        	if(rezimIzmene) {
            Object source = event.getSource();
            
            Polje poljePressed = (Polje) source;
            int[] niz = new int[2];
            niz = poljePressed.pozicijaPolja();
        	int i = niz[0];
        	int j = niz[1];
        
        	

            if(trava.getState()) {
            	if(poljePressed instanceof Zid) {
            		poljePressed = new Trava(mreza);
             
            	mreza.promeniZidZaTravu(i ,j);
            	poljePressed.setBackground(Color.GREEN);
                repaint();
          			  }
            }
             else if(zid.getState()) {
            	
            		if(poljePressed instanceof Trava) {
                    	
            			mreza.promeniTravuZaZid(i, j);
            			poljePressed.setBackground(Color.LIGHT_GRAY);
                    repaint();
                	
                 
                 	} } }
        	
        	mreza.revalidate();
        	mreza.repaint();
        	
        	
        
        	
      			  }

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
        	
        	

        }
        

      


	
	
	private void dodajListenere() {
		 for(int i = 0 ; i< mreza.dimenzija; i++)
			  for(int j = 0; j < mreza.dimenzija; j++)
				  mreza.matrica[i][j].addMouseListener(listener);
				mreza.addMouseListener(listener);
				this.addMouseListener(listener);
				panel.addMouseListener(listener);
		
		addWindowListener(new WindowAdapter() {
			 public void windowClosing(WindowEvent we) {
			 dispose(); mreza.zavrsi();
			 }});
		addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				switch(e.getKeyCode()) {
				case KeyEvent.VK_A: 								
					mreza.pomeri(Smer.LEVO);break;
				case KeyEvent.VK_D:
				    mreza.pomeri(Smer.DESNO);break;
				case KeyEvent.VK_S:
					mreza.pomeri(Smer.DOLE);break;
				case KeyEvent.VK_W:
					mreza.pomeri(Smer.GORE);break;
								}
				
			}
		});
		pocni.addActionListener(
				 new ActionListener() {
				 public void actionPerformed(
				ActionEvent e) {
					 mreza.kreni();
						requestFocus();
						azuriraj();
				 
				}
				});
	
		
		
		
	}
	
	private void azuriraj() { 
		 if(mreza.igrac != null) {
      	   mreza.igrac.dohvPolje().izbaci(mreza.igrac);
      	   mreza.igrac.dohvPolje().repaint();
      	   mreza.igrac = null;
         }
		 
		 int p = mreza.dohvListuNovcica().size();
         for(int i = 0 ; i < p; i++) {
      	   mreza.dohvListuNovcica().get(i).dohvPolje().izbaci( mreza.dohvListuNovcica().get(i));
      	 mreza.dohvListuNovcica().get(i).dohvPolje().repaint();
      
      	  
         }
		
		 mreza.dohvListuNovcica().clear();
		
		
         int pp = mreza.dohvListuTenkova().size();
         for(int i = 0 ; i < pp; i++) {
      	   mreza.dohvListuTenkova().get(i).dohvPolje().izbaci( mreza.dohvListuTenkova().get(i));
      	 mreza.dohvListuTenkova().get(i).dohvPolje().repaint();
    	   mreza.dohvListuTenkova().get(i).zavrsi(); 
      
      	   
         }
         mreza.dohvListuTenkova().clear();
         mreza.dodatiNovcici = true;
         mreza.dodatiTenkovi = true;
        poeni.setText("Poeni : 0") ;
        mreza.brPoena = 0;
       
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		 new Igra();
		 }

}
