package igra;

import java.awt.*;

import java.util.*;

import igra.Figura.Smer;
import igra.Polje.Elem;



public class Mreza extends Panel implements Runnable {
	
	protected Polje[][] matrica;
	protected Igrac igrac;
	protected Igra igra;
	protected int dimenzija;
	private Thread nit = new Thread(this);
	private boolean radi = false;
	private ArrayList<Novcic> listaNovcica = new ArrayList<>();
	private ArrayList<Tenk> listaTenkova = new ArrayList<>();
	protected int brPoena = 0;
    boolean sudarSaTenkom = false;
	
	
	public Mreza(int dim, Igra i) {
		
		dimenzija  = dim;
		setLayout(new  GridLayout(dimenzija,dimenzija));
		igra = i;
		matrica = new Polje[dimenzija][dimenzija];
		dodajPolja();
		repaint();
		nit.start();
		
	}
	public Mreza( Igra i) {
		
		dimenzija  = 17;
		setLayout(new  GridLayout(dimenzija,dimenzija));
		igra = i;
		matrica = new Polje[dimenzija][dimenzija];
	    dodajPolja();
        repaint();  		
		nit.start();
		
	}
	public void promeniZidZaTravu(int i , int j) {
		remove(matrica[i][j]);
		
		matrica[i][j] = new Trava(this);
		add(matrica[i][j], i*dimenzija + j);
		validate();
		matrica[i][j].addMouseListener(igra.listener);
		
		
	}
	
	public void promeniTravuZaZid(int i, int j) {
		remove(matrica[i][j]);
		
		matrica[i][j] = new Zid(this);
		add(matrica[i][j], i*dimenzija + j);
		validate();
		matrica[i][j].addMouseListener(igra.listener);
	
	}
	public void crtajMrezu() {

		for(int i = 0 ; i < dimenzija; i++)
			for(int j = 0; j < dimenzija; j++)
				matrica[i][j].repaint();
		
	}
	
	
	
	
	
	public synchronized void pomeri(Smer smer) {
		if(radi) {
		if(igrac == null) return;
		Polje p = igrac.dohvPolje();
		int[] niz = p.pozicijaPolja();
		int i = niz[0];
		int j = niz[1];
		
		if(smer == Smer.DESNO) {
			
			Polje pomeraj = p.dohvatiPolje(0, 1);
			if (pomeraj != null && pomeraj.mozeFigura(igrac)) {
				igrac.dohvPolje().izbaci(igrac);
				igrac.dohvPolje().repaint();
				igrac.pomeriFiguru(pomeraj); 
				pomeraj.dodaj(igrac);
                  for(Elem tek = igrac.dohvPolje().prvi; tek != null; tek = tek.sled) {
					if (tek.fig instanceof Novcic) { igrac.dohvPolje().izbaci(tek.fig); 
					igrac.dohvPolje().imaNovcic = false;
					
					listaNovcica.remove(tek.fig);
					brPoena++;
					}
					if(tek.fig instanceof Tenk) zavrsi();
				}
				pomeraj.repaint();
			}
		
			
		}else if (smer ==  Smer.LEVO) {
			Polje pomeraj = p.dohvatiPolje(0, -1);
					if (pomeraj != null && pomeraj.mozeFigura(igrac)) {
						igrac.dohvPolje().izbaci(igrac);
						igrac.dohvPolje().repaint();
						igrac.pomeriFiguru(pomeraj); 
						pomeraj.dodaj(igrac);
						for(Elem tek = igrac.dohvPolje().prvi; tek != null; tek = tek.sled) {
							
							
							if (tek.fig instanceof Novcic) { igrac.dohvPolje().izbaci(tek.fig); 
							igrac.dohvPolje().imaNovcic = false;
							
							listaNovcica.remove(tek.fig);
							brPoena++;
							}
							if(tek.fig instanceof Tenk) zavrsi();
						}
						pomeraj.repaint();
						
					}		
			
			
		}else if (smer ==  Smer.DOLE) {
			Polje pomeraj = p.dohvatiPolje(1, 0);
			if (pomeraj != null && pomeraj.mozeFigura(igrac)) {
				igrac.dohvPolje().izbaci(igrac);
				igrac.dohvPolje().repaint();
				igrac.pomeriFiguru(pomeraj); 
				pomeraj.dodaj(igrac);
            for(Elem tek = igrac.dohvPolje().prvi; tek != null; tek = tek.sled) {
					
					
					if (tek.fig instanceof Novcic) { igrac.dohvPolje().izbaci(tek.fig); 
					igrac.dohvPolje().imaNovcic = false;
					
					listaNovcica.remove(tek.fig); 
					brPoena++;
					}
					if(tek.fig instanceof Tenk) zavrsi();
				}
				pomeraj.repaint();
			}	
			
		}else {
			Polje pomeraj = p.dohvatiPolje(-1, 0);
			if (pomeraj != null && pomeraj.mozeFigura(igrac)) {
				igrac.dohvPolje().izbaci(igrac);
				igrac.dohvPolje().repaint();
				igrac.pomeriFiguru(pomeraj); 
				pomeraj.dodaj(igrac);
				for(Elem tek = igrac.dohvPolje().prvi; tek != null; tek = tek.sled) {
					
					
					if (tek.fig instanceof Novcic) { igrac.dohvPolje().izbaci(tek.fig); 
					igrac.dohvPolje().imaNovcic = false;
				
					listaNovcica.remove(tek.fig);
					brPoena++;
					}
					if(tek.fig instanceof Tenk) zavrsi();
				}
				pomeraj.repaint();
				
			}	
			
		} }
		
		
		
		
		
		
		
		}
	
	
	
	
		
	public void dodajPolja() {
		int brojPolja = dimenzija*dimenzija;
		int brojTrava = brojPolja*8/10;
		int brojZidova = brojPolja*2/10;
		
	
			for(int i = 0 ; i < dimenzija; i++)
				for(int j = 0; j < dimenzija; j++)  {
				
						if(brojTrava > 0 && brojZidova > 0) { // ima i za travu i za zidove
					if(Math.random()*100 < 80) { //dodaj travu
						Trava t = new Trava(this);
						matrica[i][j] = t; brojTrava--;
                         add(matrica[i][j]);matrica[i][j].repaint();						
					    
					} else { //dodaj zid
						Zid z = new Zid(this);
						matrica[i][j] = z; brojZidova--;
						add(matrica[i][j]);matrica[i][j].repaint();	
					}					
				} else if(brojZidova == 0) { // svi zidovi postavljeni , samo trave stavi
					Trava t = new Trava(this);
					matrica[i][j] = t; brojTrava--;add(matrica[i][j]);matrica[i][j].repaint();	
					
				} else {
					Zid z = new Zid(this);  // sve trave postavljene, samo zidove stavljaj
					matrica[i][j] = z; brojZidova--;add(matrica[i][j]);matrica[i][j].repaint();	
					
				}
						
				
				}  }
	
	public synchronized void kreni() {
		radi = true;
		notifyAll();
	}
	public void zavrsi() {
		radi = false;
		for(int i = 0 ; i < listaTenkova.size(); i++) listaTenkova.get(i).zavrsi();
		nit.interrupt();
	}
	public synchronized void stani() {
		radi = false;
		notifyAll();
	}
	
	public ArrayList<Novcic> dohvListuNovcica() {
		return listaNovcica;
	}
	public ArrayList<Tenk> dohvListuTenkova() {
		
		return listaTenkova;
	}
	
	
	
	protected boolean dodatiNovcici = true;
	public synchronized void dodajNovcice() {
		if(dodatiNovcici) {
		int brojN = Integer.parseInt(igra.brojNovcica.getText());
		
		while(brojN > 0) {
			
			Novcic novcic =null;
			boolean nijeNadjen = true;
			
			int i = (int) (Math.random() * dimenzija);
			int j = (int) (Math.random() * dimenzija);
			while(nijeNadjen) {			
			i = (int) ( Math.random() * dimenzija);
		    j = (int) (Math.random() * dimenzija);
				
			if (matrica[i][j].mozeFigura(novcic) && !(matrica[i][j].imaNovcic)) {
				
				
				matrica[i][j].imaNovcic = true;
				novcic = new Novcic(matrica[i][j]);
		     	matrica[i][j].dodaj(novcic);
		     	listaNovcica.add(novcic);
		     	matrica[i][j].repaint();	
				nijeNadjen = false;
			} 
			
			
			}
			brojN--;
		
		}
		dodatiNovcici = false;
		}
		
	}
	protected boolean dodatiTenkovi= true;
	public synchronized void dodajTenkove() {
		if(dodatiTenkovi) {
		int brojN = Integer.parseInt(igra.brojNovcica.getText())/3;
		
            while(brojN > 0) {
			
			Tenk tenk =null;
			boolean nijeNadjen = true;
			
			int i = (int) (Math.random() * dimenzija);
			int j = (int) (Math.random() * dimenzija);
			while(nijeNadjen) {			
			i = (int) ( Math.random() * dimenzija);
		    j = (int) (Math.random() * dimenzija);
				
			if (matrica[i][j].mozeFigura(tenk) ) {
				
				
				
				
				tenk = new Tenk(matrica[i][j]);
		     	matrica[i][j].dodaj(tenk);
		     	listaTenkova.add(tenk);
		     	tenk.kreni();
		     	matrica[i][j].repaint();	
				nijeNadjen = false;
				
			} 
			
			
			}
			brojN--;
		
		} dodatiTenkovi = false; }
	
		
	}
	
	public synchronized void azurirajPoene() {
		igra.poeni.setText("Poeni : " + brPoena);
	}
	
	public synchronized void napraviIgraca() {
		
		if (igrac == null) {
			
			boolean nijeNadjen = true;
			int i = (int) (Math.random() * dimenzija);
			int j = (int) (Math.random() * dimenzija);
			while(nijeNadjen) {			
			i = (int) ( Math.random() * dimenzija);
		    j = (int) (Math.random() * dimenzija);
				
			if (matrica[i][j].mozeFigura(igrac)) nijeNadjen = false;
			
			}
			
			igrac = new Igrac(matrica[i][j]);
			matrica[i][j].dodaj(igrac);
			matrica[i][j].repaint();		
			
			
		}
		
		
		
		
	}
	public synchronized void imaLiNovcica() {
		if(listaNovcica.size() == 0) {
			zavrsi();
		}
			
	}
	public synchronized void proveraSudara() {
		if (igrac != null && igrac.dohvPolje().prvi != null) {
			 for(Elem tek = igrac.dohvPolje().prvi; tek != null; tek = tek.sled) {
				 if (tek.fig instanceof Tenk) zavrsi();
			 }
			
		}
	}
	
	public void run() {
		try {
		while(!Thread.interrupted()) {
			synchronized(this) { if (!radi) wait(); }
			if(igra.rezimIgre) {
			
			napraviIgraca();
			dodajNovcice();
			dodajTenkove();
			proveraSudara();
			imaLiNovcica();
		    azurirajPoene();
			
		  
			}
			
			repaint();
			
			Thread.sleep(40);
			
			} 
		} 
		 catch(InterruptedException e) {}
	
		
	}
	

}
