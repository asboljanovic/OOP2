package igra;

import java.awt.*;

import igra.Polje.Elem;



public class Igrac extends Figura {

	public Igrac(Polje p) {
		super(p);
	
	}

	
	public void crtaj() {
		Graphics g = this.dohvPolje().getGraphics();
		g.setColor(Color.RED);
		Graphics2D g2d = (Graphics2D) g;
	      g2d.setStroke(new BasicStroke(3));
		int sir = this.dohvPolje().getWidth();
		int vis = this.dohvPolje().getHeight();
		
	
		g2d.drawLine(sir/2, 0, sir/2, vis);
		g2d.drawLine(0, vis/2, sir, vis/2);
		
	}
	
	
		
		
		


	
	
	
	
	
}
