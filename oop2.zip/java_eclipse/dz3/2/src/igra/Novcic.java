package igra;
import java.awt.*;


public class Novcic extends Figura {

	public Novcic(Polje p) {
		super(p);
		
	}

	
	public void crtaj() {
		Graphics g = this.dohvPolje().getGraphics();
		g.setColor(Color.YELLOW);
		int sir = this.dohvPolje().getWidth();
		int vis = this.dohvPolje().getHeight();
		g.fillOval(sir/4, vis/4, sir/2, vis/2);

	}

}
