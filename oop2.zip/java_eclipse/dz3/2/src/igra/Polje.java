package igra;

import java.awt.*;

public abstract class Polje extends Canvas {
	 protected Figura figura;
	 protected boolean imaNovcic= false;
	 
	 protected class Elem {
		 Figura fig;
		 Elem sled;
		 Elem(Figura f) {
			 fig = f;
			 if (prvi == null) prvi = this; else posl.sled = this;
			 posl = this;
		 }
	 }
	protected Elem prvi, posl;
	private Mreza mreza;
	private int[] niz = new int[2];
	
	public Polje(Mreza m) {
		mreza = m;
		
	}
	public synchronized void dodaj(Figura fig) {
		new Elem(fig);
	}
	public synchronized void izbaci(Figura fig) {
		Elem tek = prvi, pret = null;
		while(tek!= null && tek.fig != fig) { pret = tek; tek = tek.sled; }
		if (tek!= null) {
			if ( pret == null) prvi = tek.sled; else pret.sled = tek.sled;
			if(tek.sled == null) posl = pret;
		}
	}
	
	
	public Mreza dohvatiMrezu() { return mreza; }
	
	public   int[] pozicijaPolja() {
		 int m = 0 , n = 0;
		 for(int i = 0; i < mreza.dimenzija; i++)
		     for (int j = 0; j < mreza.dimenzija; j++)
		    	 if (mreza.matrica[i][j] == this) {
		    		 m = i;
		    		 n = j;
		    		 continue;
		    		 
		    	 }
		niz[0] = m;
		niz[1] = n;
				return niz;
			}
	
	public Polje dohvatiPolje(int i , int j) {
		int m = niz[0];
		int n = niz[1];
		
		if(m + i >= mreza.dimenzija || j + n >= mreza.dimenzija ||m + i <0 || j+n < 0 ) return null;
		
		return mreza.matrica[m+i][j+n];
		
		
	}
	
	
	public abstract boolean mozeFigura(Figura f);
	
	public abstract void paint(Graphics g);
		 
	
 
}
