package igra;

import java.awt.Color;
import java.awt.Graphics;

public class Zid extends Polje {

	
	public Zid(Mreza m) {
		super(m);
		
	}

	public boolean mozeFigura(Figura f) {
		
		return false;
	}

	public synchronized void paint(Graphics g) {
		
		this.setBackground(Color.LIGHT_GRAY);
	}

}
