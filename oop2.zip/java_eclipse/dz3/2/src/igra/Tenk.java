package igra;

import java.awt.Color;
import java.awt.Graphics;

import igra.Polje.Elem;

public class Tenk extends Figura implements Runnable {

	
	private Thread nit = new Thread(this);
	private boolean radi = false;
	
	public Tenk(Polje p) {
		super(p);
		nit.start();
		
	}
	public void zavrsi() { nit.interrupt(); }
	public synchronized void kreni() {
		radi = true;
		notifyAll();
	}
	
	public synchronized void pomeri(Smer s) {
		Polje p = this.dohvPolje();
		int[] niz = p.pozicijaPolja();
		int i = niz[0];
		int j = niz[1];
		
		if(s == Smer.DESNO) {
			
			Polje pomeraj = p.dohvatiPolje(0, 1);
			if (pomeraj != null && pomeraj.mozeFigura(this)) {
				this.dohvPolje().izbaci(this);
				this.dohvPolje().repaint();
				this.pomeriFiguru(pomeraj); 
				pomeraj.dodaj(this);
				
			}
		
			
		}else if (s ==  Smer.LEVO) {
			Polje pomeraj = p.dohvatiPolje(0, -1);
					if (pomeraj != null && pomeraj.mozeFigura(this)) {
						this.dohvPolje().izbaci(this);
						this.dohvPolje().repaint();
						this.pomeriFiguru(pomeraj); 
						pomeraj.dodaj(this);
					}		
			
			
		}else if (s ==  Smer.DOLE) {
			Polje pomeraj = p.dohvatiPolje(1, 0);
			if (pomeraj != null && pomeraj.mozeFigura(this)) {
				this.dohvPolje().izbaci(this);
				this.dohvPolje().repaint();
				this.pomeriFiguru(pomeraj); 
				pomeraj.dodaj(this);
			}	
			
		}else {
			Polje pomeraj = p.dohvatiPolje(-1, 0);
			if (pomeraj != null && pomeraj.mozeFigura(this)) {
				this.dohvPolje().izbaci(this);
				this.dohvPolje().repaint();
				this.pomeriFiguru(pomeraj); 
				pomeraj.dodaj(this);
			}	
			
		}
	
	}
	
	public synchronized void azuriraj() {
		int x = (int) (Math.random() * 4);
		if ( x == 0 ) {
			Smer s = Smer.DESNO;
			pomeri(s);
		}else if (x == 1) {
			Smer s = Smer.LEVO;
			pomeri(s);
		}else if(x == 2) {
		Smer s = Smer.DOLE;
		pomeri(s); } 
		else {
			Smer s = Smer.GORE;
			pomeri(s);
		}
		
	}


	public void run() {
		try {
			while(!Thread.interrupted()) {
				 synchronized(this) {
					 while(!radi) wait();
				 }
				 azuriraj();
				 this.dohvPolje().repaint();
				 Thread.sleep(500);
				 
			}
			
			
		}catch(InterruptedException g) {}
		

	}

	
	public void crtaj() {
		Graphics g = this.dohvPolje().getGraphics();
		g.setColor(Color.BLACK);
		int sir = this.dohvPolje().getWidth();
		int vis = this.dohvPolje().getHeight();
		g.drawLine(0, 0, sir, vis);
		g.drawLine(0, vis,sir , 0);
		

	}

}
