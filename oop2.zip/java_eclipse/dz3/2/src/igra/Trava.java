package igra;
import java.awt.*;

public class Trava extends Polje {
	
	
 

	public Trava(Mreza m) {
		super(m);
		this.setBackground(Color.GREEN);
	
		
	}


	public boolean mozeFigura(Figura f) {
		
		return true;
	}


	@Override
	public synchronized void paint(Graphics g) {
		this.setBackground(Color.GREEN);
		for(Elem tek = prvi; tek!= null; tek = tek.sled) tek.fig.crtaj();
		
		
	}

}
