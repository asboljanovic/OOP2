package igra;
import java.awt.*;

public abstract class Figura {
	
	private Polje polje;
	public enum Smer { LEVO, DESNO, GORE , DOLE  }
	
	public Figura(Polje p) {
		polje = p;
	}
	
	public Polje dohvPolje() {
		return polje;
	}
	
	public void pomeriFiguru(Polje p) {
		polje = p;
	}
	
	public boolean equals(Object o) {
		if(o == null) return false;
		if (o == this) return true;
		if(!(o instanceof Figura)) return false;
		Figura f = (Figura)o;
		if(f.polje == this.polje) return true;
		else return false;
	}
	
	public abstract void crtaj();
}
